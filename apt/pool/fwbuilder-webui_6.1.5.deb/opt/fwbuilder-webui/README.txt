Firewall Builder WebUI 6.1.5
================================

Contents:
  bin/fwbweb              native bridge ELF
  bin/fwbweb-wrapper      sets FWBUILDER_RES_DIR for this tree
  bin/fwbweb-run-stack    starts API (+ frontend)
  bin/fwb_*               compilers (if packaged)
  share/fwbweb/           backend, frontend, res
  doc/                    INSTALL / STATUS / ARCHITECTURE

Quick start:
  export FWBWEB_BRIDGE=\"$PWD/bin/fwbweb-wrapper\"
  export FWBUILDER_RES_DIR=\"$PWD/share/fwbweb/res\"
  export FWBWEB_API_TOKEN=dev-token
  # Adjust run-stack paths or:
  cd share/fwbweb/backend && python3 -m venv .venv && .venv/bin/pip install -e '.[dev]'
  .venv/bin/uvicorn fwbweb_api.main:app --host 127.0.0.1 --port 8088

See doc/INSTALL.md.
